module.exports = {
    dialect: 'postgres',
    host: 'localhost',
    username: 'postgres',
    password: 'labinfo123',
    database: 'apinode',
    define: {
        timestamps: true,
        underscored: true
    }
}