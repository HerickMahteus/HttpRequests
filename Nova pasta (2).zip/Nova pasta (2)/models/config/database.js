module.exports = {
    dialect: 'postgres',
    host: 'localhost',
    username: 'usuario',
    password: 'senha',
    database: 'apinode',
    define: {
        timestamps: true,
        underscored: true
    }
}